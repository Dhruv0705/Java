public class Bill {

    private double bill_rates;
    
    public double getbill_rate(){
        return bill_rates;
    }

    // Can write a if statement and loop according to level to calculate the rate according from timecard
    //within a class...
}
