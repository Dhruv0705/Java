package IntroToJava.VariablesNDataTypes;

public class VariableNDataType {
    
    // Method to print
    public static void main(String [] args){
        
        // Integer data type
        int num1 = 5;

        // float data type
        double num2 = 5.0;

        // Bollean data type - true or false 
        boolean b = false;

        // Single character data type - Can only be one character
        char c = 'c';

        // String Data type (must be in "")
        String str = "String";

        // Set new variable tim to old variable num1 tim now = 5
        int tim = num1;

        // Prints variables set above from data type
        System.out.println(num1);
        System.out.println(num2);
        System.out.println(b);
        System.out.println(c);
        System.out.println(str);
        System.out.println(tim);
    }
}
