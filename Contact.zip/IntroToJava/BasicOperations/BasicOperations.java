package IntroToJava.BasicOperations;

public class BasicOperations {
    
    public static void main(String [] args){

        
        int x = 5;
        int y = 7;
        int z = 57;

        double sum = x*y+(double)z;

        
        System.out.println(sum);
    }
}
